#Updating data into celebs

import sqlite3 

conn=sqlite3.connect("celebrities.db")

cursor = conn.cursor()

sql = '''update celebs set photo=replace(photo,'software4rfid','nphinity')'''

cursor.execute(sql)

#commit the changes
conn.commit()
conn.close()


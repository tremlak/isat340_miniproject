#createtable.db

#Create and connect to a database

import sqlite3 

conn=sqlite3.connect("celebrities.db")

#get a cursor to work with db
cursor = conn.cursor()

sql = "create table celebs(celebID intger PRIMARY KEY, firstname text, lastname text, age int, email text, photo text, bio text)" 

cursor.execute(sql)
conn.commit() 
conn.close()

#Updating data into celebs for FINAL

import sqlite3 

conn=sqlite3.connect("celebrities.db")

cursor = conn.cursor()

sql = '''UPDATE celebs set celebID = 1 WHERE firstname ="Angelina"'''

cursor.execute(sql)

#commit the changes
conn.commit()
conn.close()

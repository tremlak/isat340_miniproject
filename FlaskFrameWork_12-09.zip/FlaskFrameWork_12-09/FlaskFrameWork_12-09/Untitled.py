#Updating data into celebs

import sqlite3 

conn=sqlite3.connect("my_sqlite.db")

cursor = conn.cursor()

sql = '''update hobbies set hobby = "coding and nano-electronics" where id=1'''

cursor.execute(sql)

#commit the changes
conn.commit()
conn.close()

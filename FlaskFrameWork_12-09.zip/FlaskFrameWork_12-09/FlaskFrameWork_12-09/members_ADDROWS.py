#enter information into members for Final

#Alexandra Treml and Jamie Mears
 

import sqlite3 

conn=sqlite3.connect("celebrities.db")

cursor = conn.cursor()
#data supplied as as tuple of tuples ? - placeholder for data
sql = "insert into members values (?,?,?,?,?,?,?,?)"
data = ((1, "Alexandra", "Treml","20", "tremlak@dukes.jmu,edu","My name is Alexandra Treml. I am a junior ISAT major at James Madison University. I am from Harrisonville Pennsylvania. I like to rock climb and sing, and my favorite food is apples.", "tremlak", "tremlak1"),(2, "Jamie", "Mears", 20, "mearsjm@dukes.jmu.edu", "My name is Jamie Mears. I am a Junior in the ISAT program and I like to study Windmills.", "mearsjm", "mearsjm1"))

cursor.executemany(sql,data)

conn.commit()

conn.close()
